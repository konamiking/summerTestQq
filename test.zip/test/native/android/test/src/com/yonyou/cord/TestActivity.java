package com.yonyou.cord;

import android.os.Bundle;

import com.yyuap.summer.core.SummerActivity;

public class TestActivity extends SummerActivity {

	@Override
	public String getContextName() {
		// TODO Auto-generated method stub
		return "TestActivity";
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}

	@Override
	public void onInit(Bundle arg0) {
		// TODO Auto-generated method stub

	}

}
