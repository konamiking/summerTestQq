﻿

summerready = function(){
   summer.openWin({
	     id: 'main',
	     url: 'html/main.html'
	});
}