//here is your code...
summerready = function () {	
	$summer.byId("content").innerHTML += "<h1 style='text-align: center'>Hello friends, welcome to touch the summer frame!</h1><h2 style='text-align: center'>The frame update at " +(new Date()).toLocaleString()+"</h2>";	
};


function openWin(){
	summer.openWin({
	     id: 'new_page1',
	     url: 'html/new_page1.html'
	});
}
function set(obj){	
	$summer.byId("content").innerHTML += obj;
 	summer.closeWin("new_page1")
 		
}